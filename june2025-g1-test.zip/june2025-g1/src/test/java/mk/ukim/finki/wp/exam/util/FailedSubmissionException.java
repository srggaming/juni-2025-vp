package mk.ukim.finki.wp.exam.util;

public class FailedSubmissionException extends RuntimeException {
}
