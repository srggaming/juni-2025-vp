package mk.ukim.finki.wp.june2025g1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class June2025G1Application {

    public static void main(String[] args) {
        SpringApplication.run(June2025G1Application.class, args);
    }
}
