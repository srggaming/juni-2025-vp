package mk.ukim.finki.wp.june2025g1.service.impl;

public class FounderServiceImpl {
}
